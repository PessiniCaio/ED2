#ifndef BOLHACPARADA_H
#define BOLHACPARADA_H

extern double bCPT;
extern int bCPComp;
extern int bCPSwaps;
void ordenaBolhaComParada(int *dados, int tamanho);

#endif
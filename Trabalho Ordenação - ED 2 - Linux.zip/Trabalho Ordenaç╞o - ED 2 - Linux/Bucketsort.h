#ifndef BUCKETSORT_H
#define BUCKETSORT_H

extern double bSTE;
extern int bSComp;
extern int bSSwaps;

void bucketSort(int *array, int tamanho);

#endif
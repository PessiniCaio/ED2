#ifndef INSERTIONSORT_H
#define INSERTIONSORT_H

extern double iST;
extern int iSComp;
extern int iSSwaps;
void insertionSort(int *array, int tamanho);

#endif
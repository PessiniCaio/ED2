#ifndef SELECTIONSORT_H
#define SELECTIONSORT_H

extern double sSTE;
extern int sSCompE;
extern int sSSwapsE;
void swapSelection(int *a, int *b, int *sSSwaps);
void selectionSort(int *array, int tamanho);

#endif
#ifndef BOLHACPARADA_H
#define BOLHACPARADA_H

extern double bCPT;
extern long long int bCPComp;
extern long long int bCPSwaps;
void ordenaBolhaComParada(int *dados, int tamanho);

#endif
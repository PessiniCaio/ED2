#ifndef BOLHASEMPARADA_H
#define BOLHASEMPARADA_H

extern double bSPT;
extern long long int bSPComp;           
extern long long int bSPSwaps;
void ordenaBolhaSemParada(int *dados, int tamanho);

#endif
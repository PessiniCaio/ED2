#ifndef BOLHASEMPARADA_H
#define BOLHASEMPARADA_H

extern double bSPT;
extern int bSPComp;           
extern int bSPSwaps;
void ordenaBolhaSemParada(int *dados, int tamanho);

#endif
#ifndef BUCKETSORT_H
#define BUCKETSORT_H

extern double bSTE;
extern long long int bSComp;
extern long long int bSSwaps;

void bucketSort(int *V, int tamanho);

#endif
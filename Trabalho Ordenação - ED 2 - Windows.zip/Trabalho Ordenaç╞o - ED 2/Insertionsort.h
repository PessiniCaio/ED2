#ifndef INSERTIONSORT_H
#define INSERTIONSORT_H

extern double iST;
extern long long int iSComp;
extern long long int iSSwaps;
void insertionSort(int *array, int tamanho);

#endif
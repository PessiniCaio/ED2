#ifndef MENUS_H
#define MENUS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void menu_principal();
void menu_ordem(int base_opcao);
void menu_ordenacao(const char *caminho);

#endif 

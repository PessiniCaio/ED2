#ifndef SELECTIONSORT_H
#define SELECTIONSORT_H

extern double sSTE;
extern int long long sSCompE;
extern int long long sSSwapsE;
void swapSelection(int *a, int *b, long long int *sSSwaps);
void selectionSort(int *array, int tamanho);

#endif
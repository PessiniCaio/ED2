#ifndef SHELLSORT_H
#define SHELLSORT_H

extern double sST;
extern long long int sSComp;
extern long long int sSSwaps;

void shellSort(int *dados, int tamanho);

#endif
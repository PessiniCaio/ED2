#ifndef BOLHACPARADA_H
#define BOLHACPARADA_H

void ordenaBolhaComParada(int *dados, int tamanho);

#endif
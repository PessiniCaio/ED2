#ifndef BOLHASEMPARADA_H
#define BOLHASEMPARADA_H

void ordenaBolhaSemParada(int *dados, int tamanho);

#endif
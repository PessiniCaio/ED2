#ifndef SHELLSORT_H
#define SHELLSORT_H

extern double sST;
extern int sSComp;
extern int sSSwaps;

void shellSort(int *dados, int tamanho);

#endif